
public class Customer extends Person{

	Customer(String name) {
		super(name);
	}
	
	
}
