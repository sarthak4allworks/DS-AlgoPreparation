
public class PersonNotExistException extends Exception{

	public PersonNotExistException() {
		super("Person does not exist");
	}
	
}
